const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { runScraper } = require('../controllers/priceScraperController');

// Admin only trigger
router.post('/scraper/run', auth, role(['admin']), runScraper);

module.exports = router;