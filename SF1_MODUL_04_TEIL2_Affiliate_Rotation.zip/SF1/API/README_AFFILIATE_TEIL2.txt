📈 Affiliate-System – Teil 2:
- Modelle:
  • AffiliateClick: Logs Klicks mit userId (optional), IP, UserAgent, Timestamp
- Services:
  • getAffiliateLink(seedbank): holt Link-Daten
  • recordClick(linkId, userId, ip, userAgent): speichert Klick
- Controller:
  • GET /affiliate/:seedbank → leitet weiter auf URL, trackt Klick (auth optional)
- Middleware:
  • authOptional: erkennt JWT, füllt req.user wenn vorhanden
- Usage:
  • Frontend nutzt Link [HOST]/affiliate/<seedbank>