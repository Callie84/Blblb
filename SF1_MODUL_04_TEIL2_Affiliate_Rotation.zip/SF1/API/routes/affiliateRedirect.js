const express = require('express');
const router = express.Router();
const authOptional = require('../middleware/authOptional'); // allows req.user if present
const { redirectToAffiliate } = require('../controllers/affiliateController');

// Redirect to affiliate link and track click
router.get('/:seedbank', authOptional, redirectToAffiliate);

module.exports = router;