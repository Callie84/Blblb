const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { classify, submitFeedback } = require('../controllers/feedbackController');

// Auth nötig
router.use(auth);

// Detailed classification
router.get('/:id/classify', classify);

// Submit feedback
router.post('/:id/feedback', express.json(), submitFeedback);

module.exports = router;