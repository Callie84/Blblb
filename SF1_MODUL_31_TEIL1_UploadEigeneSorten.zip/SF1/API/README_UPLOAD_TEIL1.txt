📤 Upload eigener Sorten – Teil 1:
- Modell: UploadedSeed (Strain, Genetik, THC, CBD, Beschreibung, Bild-URL)
- Route: POST /upload (Form-Field 'image' optional für Foto)
- Route: GET /upload (Liste eigener Uploads)
- Auth erforderlich