const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { listTemplates, getTemplate } = require('../controllers/templateController');

router.use(auth);

// Raum-Templates
router.get('/templates', listTemplates);
router.get('/templates/:id', getTemplate);

module.exports = router;