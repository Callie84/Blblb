const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { updateAll, getOffers } = require('../controllers/integratedPriceController');

// Admin triggers full update
router.post('/affiliate/update-all', auth, role(['admin']), updateAll);

// Public or auth: get combined offers
router.get('/affiliate/offers/:strain', auth, getOffers);

module.exports = router;