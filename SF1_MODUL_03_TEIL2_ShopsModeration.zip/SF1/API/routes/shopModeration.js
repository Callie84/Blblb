const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const { updateShop, deleteShop } = require("../controllers/shopModerationController");

router.use(auth, role(["admin"]));

router.put("/shops/:id", updateShop);
router.delete("/shops/:id", deleteShop);

module.exports = router;