const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const { deleteReview } = require("../controllers/reviewModerationController");

router.use(auth, role(["admin"]));

router.delete("/reviews/:id", deleteReview);

module.exports = router;