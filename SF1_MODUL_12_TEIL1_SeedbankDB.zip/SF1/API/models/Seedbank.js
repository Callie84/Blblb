const mongoose = require('mongoose');

const SeedbankSchema = new mongoose.Schema({
  name: { type: String, unique: true, required: true },
  url: String,
  countries: [String],
  paymentMethods: [String],
  rating: Number,
  affiliateId: String,
  shipping: {
    cost: Number,
    currency: { type: String, default: 'EUR' },
    estimatedDays: Number
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

SeedbankSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Seedbank', SeedbankSchema);