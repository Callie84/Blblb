const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { deleteChannel, deleteMessage } = require('../controllers/communityModerationController');

router.use(auth, role(['admin']));

router.delete('/channels/:id', deleteChannel);
router.delete('/messages/:id', deleteMessage);

module.exports = router;