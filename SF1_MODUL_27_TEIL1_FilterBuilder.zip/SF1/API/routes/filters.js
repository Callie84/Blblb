const express = require("express");
const router = express.Router();
const Seed = require("../models/Seed");

// Liste verfügbarer Filterfelder
const validFields = ["seedbank", "genetics", "flowering_time", "indoor_yield"];

// GET /filters – alle Filterfelder anzeigen
router.get("/", (req, res) => {
  res.json(validFields);
});

// GET /filters/:field – eindeutige Werte für ein Feld
router.get("/:field", async (req, res) => {
  const field = req.params.field;
  if (!validFields.includes(field)) {
    return res.status(400).json({ error: "Ungültiges Filterfeld" });
  }
  const values = await Seed.distinct(field);
  res.json(values);
});

module.exports = router;