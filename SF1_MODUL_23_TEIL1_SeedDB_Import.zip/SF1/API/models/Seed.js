const mongoose = require('mongoose');

const PriceSchema = new mongoose.Schema({
  seedbank: String,
  packSize: String,
  priceEur: Number,
  url: String,
  lastUpdated: { type: Date, default: Date.now }
}, { _id: false });

const SeedSchema = new mongoose.Schema({
  strain: { type: String, unique: true, required: true },
  genetics: String,
  breeder: String,
  thc: Number,
  cbd: Number,
  floweringTime: String,
  indoorYield: String,
  images: [String],
  priceOffers: [PriceSchema],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

SeedSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Seed', SeedSchema);