const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { saveSettings, getExternalData, sendManualSMS } = require('../controllers/integrationController');

// Einstellungen (SMS/API)
router.post('/settings', auth, express.json(), saveSettings);

// Externe Sensor-Daten
router.get('/external/:networkId', auth, getExternalData);

// SMS manuell
router.post('/sms', auth, express.json(), sendManualSMS);

module.exports = router;