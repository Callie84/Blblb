const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/communityController');

// Channels
router.get('/channels', auth, ctl.listChannels);
router.post('/channels', auth, ctl.createChannel);

// Messages
router.post('/messages', auth, ctl.postMessage);
router.get('/messages/:channelId', auth, ctl.getMessages);

module.exports = router;