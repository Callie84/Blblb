const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { postReading, getReadings } = require('../controllers/sensorController');

// Sensor-Daten sicher aufnehmen
router.post('/readings', auth, postReading);

// Sensor-Daten abrufen
router.get('/readings', auth, getReadings);

module.exports = router;