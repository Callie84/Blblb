🔒 Admin Panel – Teil 1:
- /admin/users  (GET): Liste aller Nutzer
- /admin/logs   (GET): Letzte 100 Admin-Aktionen
- /admin/seedbanks (GET): Übersicht Seedbanks
- /admin/alerts (GET): Übersicht aller Preisalarme
- Auth + Rolle 'admin' erforderlich