const express = require("express");
const router = express.Router();
const { serveAd, clickAd } = require("../controllers/adServeController");

// GET /ads/serve/:position
router.get("/serve/:position", serveAd);

// POST /ads/click/:id
router.post("/click/:id", clickAd);

module.exports = router;