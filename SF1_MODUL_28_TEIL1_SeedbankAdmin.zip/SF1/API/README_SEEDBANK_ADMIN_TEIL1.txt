🏢 Seedbank-Management – Teil 1:
- Admin-Routen für CRUD auf Seedbanks
- Auth + Rolle 'admin' erforderlich
- Modell 'Seedbank' erweitert um URL, Länder, Zahlungsmethoden, Rating, Affiliate, Versanddaten
- Endpunkte:
  • GET /seedbanksAdmin
  • POST /seedbanksAdmin
  • PUT /seedbanksAdmin/:id
  • DELETE /seedbanksAdmin/:id