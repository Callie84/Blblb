const mongoose = require("mongoose");

const SeedbankSchema = new mongoose.Schema({
  name: { type: String, unique: true, required: true },
  url: { type: String, required: true },
  countries: [String],
  paymentMethods: [String],
  rating: { type: Number, min: 0, max: 5 },
  affiliateId: String,
  shipping: {
    cost: Number,
    currency: { type: String, default: "EUR" },
    estimatedDays: Number
  },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Middleware to update 'updatedAt'
SeedbankSchema.pre("save", function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("Seedbank", SeedbankSchema);