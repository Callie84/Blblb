const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const User = require("../models/User");
const UserExt = require("../models/UserExtension");

// Favorit hinzufügen
router.post("/favorite", auth, async (req, res) => {
  const { strain } = req.body;
  let entry = await UserExt.findOne({ userId: req.user.id });
  if (!entry) entry = new UserExt({ userId: req.user.id, favorites: [strain] });
  else if (!entry.favorites.includes(strain)) entry.favorites.push(strain);
  await entry.save();
  res.json(entry);
});

// Favoriten anzeigen
router.get("/favorites", auth, async (req, res) => {
  const entry = await UserExt.findOne({ userId: req.user.id });
  res.json(entry?.favorites || []);
});

// Premiumstatus anzeigen
router.get("/premium", auth, async (req, res) => {
  const entry = await UserExt.findOne({ userId: req.user.id });
  res.json({ premium: entry?.premium || false });
});

// Benutzerkonto löschen
router.delete("/delete", auth, async (req, res) => {
  await UserExt.deleteOne({ userId: req.user.id });
  await User.deleteOne({ _id: req.user.id });
  res.json({ message: "Konto gelöscht" });
});

module.exports = router;