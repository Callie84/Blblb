const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const PriceAlert = require("../models/PriceAlert");

// Preisalarm erstellen
router.post("/", auth, async (req, res) => {
  const { strain, seedbank, targetPrice, currency } = req.body;
  const alert = new PriceAlert({ userId: req.user.id, strain, seedbank, targetPrice, currency });
  await alert.save();
  res.status(201).json(alert);
});

// Alle Alarme des Nutzers anzeigen
router.get("/", auth, async (req, res) => {
  const alerts = await PriceAlert.find({ userId: req.user.id });
  res.json(alerts);
});

// Alarm löschen
router.delete("/:id", auth, async (req, res) => {
  await PriceAlert.deleteOne({ _id: req.params.id, userId: req.user.id });
  res.json({ message: "Alarm gelöscht" });
});

module.exports = router;