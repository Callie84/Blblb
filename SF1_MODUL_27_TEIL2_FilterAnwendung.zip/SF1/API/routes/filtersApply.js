const express = require("express");
const router = express.Router();
const { applyFilters } = require("../controllers/filterController");

// GET /filters/apply
router.get("/apply", applyFilters);

module.exports = router;