🌱 Grow-Tagebuch – Teil 1:
- POST /growlog → Neues Logbuch starten
- POST /growlog/:id/entry → Eintrag hinzufügen (mit Stadium, Bildern, Notiz)
- GET /growlog → Eigene Logs abrufen