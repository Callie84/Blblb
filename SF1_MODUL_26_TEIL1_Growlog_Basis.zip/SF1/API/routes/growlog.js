const express = require("express");
const router = express.Router();
const Growlog = require("../models/Growlog");
const auth = require("../middleware/authMiddleware");

// Neuen Growlog anlegen
router.post("/", auth, async (req, res) => {
  const { title, strain, startedAt } = req.body;
  const log = new Growlog({ userId: req.user.id, title, strain, startedAt });
  await log.save();
  res.status(201).json(log);
});

// Eintrag hinzufügen
router.post("/:id/entry", auth, async (req, res) => {
  const { date, note, stage, images } = req.body;
  const log = await Growlog.findOne({ _id: req.params.id, userId: req.user.id });
  if (!log) return res.status(404).json({ error: "Logbuch nicht gefunden" });

  log.entries.push({ date, note, stage, images });
  await log.save();
  res.json(log);
});

// Alle Logs
router.get("/", auth, async (req, res) => {
  const logs = await Growlog.find({ userId: req.user.id });
  res.json(logs);
});

module.exports = router;