const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');

// Download kompletter Export als JSON
router.get('/export/json', auth, async (req, res) => {
  const controller = require('../controllers/exportController');
  await controller.downloadJSON(req, res);
});

// Download einzelner Collections als CSV
router.get('/export/csv', auth, async (req, res) => {
  const controller = require('../controllers/exportController');
  await controller.downloadCSV(req, res);
});

module.exports = router;