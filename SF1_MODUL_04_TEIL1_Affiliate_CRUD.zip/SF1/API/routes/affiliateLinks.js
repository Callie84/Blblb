const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const controller = require('../controllers/affiliateLinkController');

// Admin-only CRUD
router.use(auth, role(['admin']));

router.get('/', controller.listAffiliateLinks);
router.post('/', controller.createAffiliateLink);
router.put('/:id', controller.updateAffiliateLink);
router.delete('/:id', controller.deleteAffiliateLink);

module.exports = router;