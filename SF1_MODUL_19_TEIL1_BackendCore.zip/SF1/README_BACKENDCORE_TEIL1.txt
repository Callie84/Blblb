🛠 Modul 19 – Teil 1: Backend Core
- server.js: Initialisiert Express, verbindet MongoDB, registriert alle Routen
- .env.example: Beispiel für Umgebungsvariablen
- API-Grundgerüst: `/api/seeds`, `/api/auth`, `/api/profile`, `/api/wishlist`, `/api/shops`, `/api/reviews` etc.
- Error-Handling Middleware
- Port konfigurierbar via `PORT`
- NPM-Skripte: `start`, `dev` (nodemon)