const express = require("express");
const router = express.Router();
const Statistik = require("../models/Statistik");

// Zugriffszahl hochzählen
router.post("/track", async (req, res) => {
  const { strain, type } = req.body;
  if (!strain || !type) return res.status(400).json({ error: "Fehlende Daten" });

  const validTypes = ["views", "searches", "clicks"];
  if (!validTypes.includes(type)) return res.status(400).json({ error: "Ungültiger Typ" });

  let entry = await Statistik.findOne({ strain });
  if (!entry) entry = new Statistik({ strain });

  entry[type]++;
  entry.updatedAt = new Date();
  await entry.save();

  res.json(entry);
});

// Beliebteste Sorten abfragen
router.get("/top", async (req, res) => {
  const top = await Statistik.find().sort({ views: -1 }).limit(10);
  res.json(top);
});

module.exports = router;