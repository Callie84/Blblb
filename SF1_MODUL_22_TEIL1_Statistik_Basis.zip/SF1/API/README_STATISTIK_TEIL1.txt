📊 Statistik & Trends – Teil 1:
- POST /stats/track: Zugriff (view/search/click) für Sorte hochzählen
- GET /stats/top: Top-Sorten nach Views anzeigen
- Modell: Statistik.js (strain, views, searches, clicks)