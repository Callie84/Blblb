const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { createThreshold, listThresholds, deleteThreshold } = require('../controllers/thresholdController');

router.use(auth);

// CRUD Thresholds
router.post('/', createThreshold);
router.get('/', listThresholds);
router.delete('/:id', deleteThreshold);

module.exports = router;