📊 Statistik & Trends – Teil 2:
- GET /stats/top-clicks: Sorten mit den meisten Klicks
- GET /stats/top-searches: Sorten mit den meisten Suchvorgängen
- GET /stats/all: Alle Datensätze (neueste zuerst)