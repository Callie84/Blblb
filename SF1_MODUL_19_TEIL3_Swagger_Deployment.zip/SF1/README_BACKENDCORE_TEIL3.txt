📜 Modul 19 – Teil 3: Swagger & Deployment
- **Swagger UI**:
  • Datei: API/swagger.js
  • Mount: `/api/docs`
  • Generiert API-Doku aus JSDoc-Kommentaren in Routen/Controllern
- **Docker**:
  • Dockerfile für Node.js Alpine-Image
  • docker-compose.yml mit Services: mongo & app
  • Produktions-Install: `npm ci --only=production`
  • Umgebungsvariablen in compose: MONGO_URI, JWT_SECRET
- **Anwendung**:
  • `docker-compose up --build`
  • API erreichbar auf `localhost:3000/api`
  • Swagger UI unter `localhost:3000/api/docs`