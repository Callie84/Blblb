const express = require("express");
const router = express.Router();
const { addReview, listReviews } = require("../controllers/reviewController");
const auth = require("../middleware/authMiddleware");

// Add review (authenticated)
router.post("/", auth, addReview);

// List reviews for a shop
router.get("/:shopId", listReviews);

module.exports = router;