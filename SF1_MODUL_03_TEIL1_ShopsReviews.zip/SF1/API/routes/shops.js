const express = require("express");
const router = express.Router();
const { listShops, addShop } = require("../controllers/shopController");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");

// Public: list shops
router.get("/", listShops);

// Admin adds shop
router.post("/", auth, role(["admin"]), addShop);

module.exports = router;