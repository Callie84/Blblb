const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const controller = require('../controllers/affiliateConnectorController');

// Partner-API-Konnektoren (auth optional/enforced)
router.get('/connect/seedexpress/:strain', auth, controller.seedExpress);
router.get('/connect/greenshop/:strain', auth, controller.greenShop);

module.exports = router;