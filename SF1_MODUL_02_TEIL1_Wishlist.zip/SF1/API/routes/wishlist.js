const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/wishlistController');

router.use(auth);

// Wunschlisten-Management
router.get('/lists', ctl.getLists);
router.post('/lists', ctl.createList);
router.delete('/lists/:id', ctl.deleteList);

// Items
router.post('/lists/:id/items', ctl.addItem);
router.delete('/lists/:id/items/:strain', ctl.removeItem);

module.exports = router;