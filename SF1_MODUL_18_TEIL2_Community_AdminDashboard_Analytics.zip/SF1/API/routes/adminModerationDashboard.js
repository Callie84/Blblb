const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { getModerationLogs } = require('../controllers/adminModerationDashboardController');

router.use(auth, role(['admin']));

// GET /admin/moderation/logs?actionType=&since=
router.get('/logs', getModerationLogs);

module.exports = router;