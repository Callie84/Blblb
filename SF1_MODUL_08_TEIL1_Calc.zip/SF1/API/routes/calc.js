const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { powerCost, yieldEstimate } = require('../controllers/calcController');

// Stromkosten berechnen
router.post('/power', auth, powerCost);

// Ertrag schätzen
router.post('/yield', auth, yieldEstimate);

module.exports = router;