let favoriten = [];

function addFavorite() {
  const input = document.getElementById('newFavorite');
  const value = input.value.trim();
  if (value === '') return;
  favoriten.push(value);
  input.value = '';
  renderFavoriten();
  saveToLocalStorage();
}

function renderFavoriten() {
  const list = document.getElementById('favoriteList');
  list.innerHTML = '';
  favoriten.forEach((f, i) => {
    const li = document.createElement('li');
    li.innerHTML = \`\${f} <button onclick="removeFavorite(\${i})" class="text-red-600 ml-2">✖</button>\`;
    list.appendChild(li);
  });
}

function removeFavorite(index) {
  favoriten.splice(index, 1);
  renderFavoriten();
  saveToLocalStorage();
}

function saveToLocalStorage() {
  localStorage.setItem('sf1_favorites', JSON.stringify(favoriten));
}

function loadFromLocalStorage() {
  const stored = localStorage.getItem('sf1_favorites');
  if (stored) favoriten = JSON.parse(stored);
  renderFavoriten();
}

window.onload = loadFromLocalStorage;