const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { compare, exportCSV } = require('../controllers/compareController');

// Vergleich
router.post('/compare', auth, compare);

// CSV-Export
router.post('/compare/export', auth, express.json(), exportCSV);

module.exports = router;