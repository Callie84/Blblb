const express = require("express");
const router = express.Router();
const Growlog = require("../models/Growlog");
const auth = require("../middleware/authMiddleware");

// Eintrag bearbeiten
router.put("/:id/entry/:entryId", auth, async (req, res) => {
  const { date, note, stage, images } = req.body;
  const log = await Growlog.findOne({ _id: req.params.id, userId: req.user.id });
  if (!log) return res.status(404).json({ error: "Logbuch nicht gefunden" });

  const entry = log.entries.id(req.params.entryId);
  if (!entry) return res.status(404).json({ error: "Eintrag nicht gefunden" });

  if (date) entry.date = date;
  if (note !== undefined) entry.note = note;
  if (stage) entry.stage = stage;
  if (images) entry.images = images;
  await log.save();
  res.json(log);
});

// Eintrag löschen
router.delete("/:id/entry/:entryId", auth, async (req, res) => {
  const log = await Growlog.findOne({ _id: req.params.id, userId: req.user.id });
  if (!log) return res.status(404).json({ error: "Logbuch nicht gefunden" });

  const entry = log.entries.id(req.params.entryId);
  if (!entry) return res.status(404).json({ error: "Eintrag nicht gefunden" });
  entry.remove();
  await log.save();
  res.json({ message: "Eintrag gelöscht" });
});

// Statistiken anzeigen (Anzahl Einträge)
router.get("/:id/stats", auth, async (req, res) => {
  const log = await Growlog.findOne({ _id: req.params.id, userId: req.user.id });
  if (!log) return res.status(404).json({ error: "Logbuch nicht gefunden" });

  res.json({
    totalEntries: log.entries.length,
    stages: log.entries.reduce((acc, e) => {
      acc[e.stage] = (acc[e.stage] || 0) + 1;
      return acc;
    }, {})
  });
});