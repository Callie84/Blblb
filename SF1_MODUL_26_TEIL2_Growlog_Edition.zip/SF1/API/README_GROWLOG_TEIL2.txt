🌱 Grow-Tagebuch – Teil 2:
- PUT /growlog/:id/entry/:entryId → Eintrag bearbeiten (Datum, Notiz, Stadium, Bilder)
- DELETE /growlog/:id/entry/:entryId → Eintrag löschen
- GET /growlog/:id/stats → Statistiken (Gesamtzahl Einträge, Verteilung nach Stadium)