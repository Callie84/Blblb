const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const {
  getGroups,
  createGroup,
  addListToGroup,
  removeListFromGroup,
  deleteGroup
} = require('../controllers/groupController');

router.use(auth);

router.get('/', getGroups);
router.post('/', createGroup);
router.post('/:groupId/add', addListToGroup);
router.post('/:groupId/remove/:wishlistId', removeListFromGroup);
router.delete('/:groupId', deleteGroup);

module.exports = router;