// Erweiterung des Modells für Moderation
const mongoose = require('mongoose');

const ModerationSchema = new mongoose.Schema({
  approved: Boolean,
  feedback: String,
  reviewedAt: Date
}, { _id: false });

// bereits bestehendes UploadedSeedSchema um Moderation erweitern
const UploadedSeedSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  strain: { type: String, required: true },
  genetics: String,
  thc: Number,
  cbd: Number,
  description: String,
  imageUrl: String,
  createdAt: { type: Date, default: Date.now },
  moderation: ModerationSchema
});

module.exports = mongoose.model('UploadedSeed', UploadedSeedSchema);