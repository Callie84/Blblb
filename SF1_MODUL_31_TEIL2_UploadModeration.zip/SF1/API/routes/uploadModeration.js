const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const { reviewUpload, getStatus } = require("../controllers/uploadModerationController");

// Admin-only Review-Route
router.post("/review/:id", auth, role(["admin"]), reviewUpload);

// Nutzer holt Status
router.get("/status", auth, getStatus);

module.exports = router;