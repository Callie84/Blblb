const mongoose = require("mongoose");

const AffiliateLinkSchema = new mongoose.Schema({
  seedbank: String,
  url: String,
  affiliateId: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("AffiliateLink", AffiliateLinkSchema);