const mongoose = require("mongoose");

const AdSchema = new mongoose.Schema({
  title: String,
  imageUrl: String,
  targetUrl: String,
  position: String, // z.B. 'banner_top', 'sidebar'
  active: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

AdSchema.pre("save", function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("Ad", AdSchema);