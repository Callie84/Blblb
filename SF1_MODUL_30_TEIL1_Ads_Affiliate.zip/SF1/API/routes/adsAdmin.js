const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const controller = require("../controllers/adController");

// Admin-only
router.use(auth, role(["admin"]));

router.get("/ads", controller.listAds);
router.post("/ads", controller.createAd);
router.put("/ads/:id", controller.updateAd);
router.delete("/ads/:id", controller.deleteAd);

router.get("/affiliate", controller.listAffiliate);
router.post("/affiliate", controller.createAffiliate);
router.put("/affiliate/:id", controller.updateAffiliate);
router.delete("/affiliate/:id", controller.deleteAffiliate);

module.exports = router;