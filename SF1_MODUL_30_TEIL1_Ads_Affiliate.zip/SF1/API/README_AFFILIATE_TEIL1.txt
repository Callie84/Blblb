📢 Werbung & Affiliate – Teil 1:
- Modelle:
  • Ad (title, imageUrl, targetUrl, position, active)
  • AffiliateLink (seedbank, url, affiliateId)
- Admin-Routen (/adsAdmin):
  • GET /ads, POST /ads, PUT /ads/:id, DELETE /ads/:id
  • GET /affiliate, POST /affiliate, PUT /affiliate/:id, DELETE /affiliate/:id
- Auth + Rolle 'admin' erforderlich