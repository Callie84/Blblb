🔖 Sorten-Merkliste – Teil 1:
- POST /bookmark → Sorte merken + optional Notiz
- GET /bookmark → Alle eigenen Merklisten-Einträge
- DELETE /bookmark/:id → Eintrag löschen