const express = require("express");
const router = express.Router();
const Bookmark = require("../models/Bookmark");
const auth = require("../middleware/authMiddleware");

// Merken
router.post("/", auth, async (req, res) => {
  const { strain, note } = req.body;
  const item = new Bookmark({ userId: req.user.id, strain, note });
  await item.save();
  res.status(201).json(item);
});

// Alle Merkliste-Einträge
router.get("/", auth, async (req, res) => {
  const list = await Bookmark.find({ userId: req.user.id });
  res.json(list);
});

// Löschen
router.delete("/:id", auth, async (req, res) => {
  await Bookmark.deleteOne({ _id: req.params.id, userId: req.user.id });
  res.json({ message: "Eintrag gelöscht" });
});

module.exports = router;